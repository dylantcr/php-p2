<?php
// auteur: D.Mahn
// functie: configuratiebestand

//namen geven
define("DATABASE", "bieren");
define("SERVERNAME", "localhost");
define("USERNAME", "root");
define("PASSWORD", "");

define("CRUD_TABLE", "kroeg");

?>